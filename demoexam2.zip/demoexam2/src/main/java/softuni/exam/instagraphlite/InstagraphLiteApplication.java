package softuni.exam.instagraphlite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InstagraphLiteApplication {

    public static void main(String[] args) {
        SpringApplication.run(InstagraphLiteApplication.class, args);
    }

}
